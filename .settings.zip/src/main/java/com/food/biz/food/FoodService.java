package com.food.biz.food;

import java.util.List;

public interface FoodService {
	 List<FoodVO> getFoodList();
}
