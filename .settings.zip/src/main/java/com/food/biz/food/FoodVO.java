package com.food.biz.food;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter@Setter@ToString
public class FoodVO {
   String food_code;
   String food_name;
   String food_unit;
}